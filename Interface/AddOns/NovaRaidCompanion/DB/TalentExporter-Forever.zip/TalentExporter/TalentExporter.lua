_, NTE = ...;
local talentData = {};
local LibTalentTree = LibStub("LibTalentTree-1.0");
--Created by Venomisto (Novaspark-Arugal)
--Exports the same data structure as earlier versions of the Talented addon.
--Modify the NTE:generateTalentData() func to suit your data structure needs.

--Preloaded with cata talents for all classes.

--If you want a diff expansion:
--Download Talent.csv from wago tools, run this lib https://github.com/geoffleyland/lua-csv.
--Paste the data table below.

--[[
local csv = require("lua-csv/lua/csv")
local f = csv.open("Talent.csv")
print("local data = {")
for row in f:lines() do
    local talentID = row[1];
    local tier1 = row[14];
    local tier2 = row[15];
    local tier3 = row[16];
    local tier4 = row[17];
    local tier5 = row[18];
    print("\t[" .. talentID .. "]={" .. tier1 .. "," .. tier2 .. "," .. tier3 .. "," .. tier4 .. "," .. tier5 .. "},");
end
print("};")
]]

--Forever data.
--[talentID] = {tier1,tier2,tier3,tier4,tier5}
local data = {
	--No talent ranks data from db2 in forever, we instead load tooltips directly from the game since you can get other classes than yourself in this version.
};


local function updateSavedVariables()
	local count, spellIDs = 0, 0;
	for tab, tabData in pairs(talentData) do
		if (tabData.talents) then
			for k, v in pairs(tabData.talents) do
				count = count + 1;
				if (v.info.talentRankSpellIds) then
					spellIDs = spellIDs + 1;
				end
			end
		end
	end
	NTEdatabase = talentData;
	print("Talent DB exported - Talents recorded with SpellID entries:", spellIDs .. "/" .. count);
end

local function debug(...)
	local data = ...;
	if (data) then
		if (type(data) == "table") then
			C_AddOns.LoadAddOn("Blizzard_DebugTools");
			--DevTools_Dump(data);
    		DisplayTableInspectorWindow(data);
    	else
			print("TEDebug:", ...);
		end
	end
end

local function pairsByKeys(t, f)
	local a = {};
	for n in pairs(t) do
		tinsert(a, n);
	end
	table.sort(a, f);
	local i = 0;
	local iter = function()
		i = i + 1;
		if (a[i] == nil) then
			return nil;
		else
			return a[i], t[a[i]];
		end
	end
	return iter;
end

function NTE:generateTalentData(class)
	class = string.upper(class);
	local audit = 0;
	local errors = {};
	local data = {};
	--This is a mixture of new stuff and stuff from my old era talent exporter, it might look a bit odd.
	--It has to build the old structure that matches the era data to work with the rest of the addon.
	local treeID = LibTalentTree:GetClassTreeID(class); --Get the single classID for this class (forever has 1 tree only that poiints to the entire class)
	local configID = Constants.TraitConsts.VIEW_TRAIT_CONFIG_ID;
	local temp = {};
    local nodes = C_Traits.GetTreeNodes(treeID)
    for i, nodeID in ipairs(nodes) do
    	local nodeInfo = C_Traits.GetNodeInfo(configID, nodeID);
    	if (not nodeInfo) then
    		debug("Missing nodeinfo:", i, nodeID, treeID);
    		return;
    	end
    	local spellInfo;
		for _, entryID in pairs(nodeInfo.entryIDs) do
			local entryInfo = C_Traits.GetEntryInfo(configID, entryID)
		    if entryInfo and entryInfo.definitionID then
		        local definitionInfo = C_Traits.GetDefinitionInfo(entryInfo.definitionID)
		        spellInfo = C_Spell.GetSpellInfo(definitionInfo.spellID);
		    end
		end
    	local column, row = LibTalentTree:GetNodeGridPosition(nodeID);
    	--If column or row is mssing it's a talent outside the UI blizz hasn't removed yet.
    	if (column and row) then
	    	local tab = column < 5 and 1 or column < 9 and 2 or 3;
	    	--Convert the overall column to per spec column.
	    	if (tab == 2) then
	    		column = column - 4;
	    	end
	    	if (tab == 3) then
	    		column = column - 8;
	    	end
			local t = {
				row = row,
				icon = spellInfo.iconID,
				ranks = nodeInfo.maxRanks,
				--wowTreeIndex = count, --This is inserted below.
				column = column,
				name = spellInfo.name,
				nodeID = nodeID,
			};
			
			local talentInfoQuery = {
				specializationIndex = 1,
			    talentIndex = 1,
			    --tier = 1,
			};
			--talentID is dead in forever.
			--[[local talentInfo = C_SpecializationInfo.GetTalentInfo(talentInfoQuery);
			local talentID = talentInfo.talentID;
			if (data[talentID]) then
				local r = {};
				for k, v in pairs(data[talentID]) do
					--0 means no rank exists for this rank num.
					if (v ~= 0) then
						tinsert(r, v);
					end
				end
				t.talentRankSpellIds = r;
			end]]
			
			if (not temp[tab]) then
	    		temp[tab] = {};
	    	end
			tinsert(temp[tab], t);
			temp[tab].treeID = treeID;
			audit = audit + 1;
		end
    end
	
	for tab, tabData in ipairs(temp) do
		data[tab] = {};
		data[tab].talents = {};
		local count = 0;
		for k, v in ipairs(tabData) do
			count = count + 1;
			data[tab].talents[count] = {};
			data[tab].talents[count].info = {
				row = v.row,
				icon = v.icon,
				ranks = v.ranks,
				--wowTreeIndex = count, --This is inserted below.
				column = v.column,
				name = v.name,
				talentRankSpellIds = v.talentRankSpellIds;
				nodeID = v.nodeID,
			};
			--audit = audit + 1;
		end
		data[tab].numtalents = count;
		local displayInfo = C_Traits.GetGroupDisplayInfoByTreeID(tabData.treeID);
		data[tab].info = {
			--background = "PaladinHoly", --We don't us background in Forever, using the new atlas instead.
			name = displayInfo[tab].displayName,
			icon = displayInfo[tab].icon,
		};
	end
	--Now we have the data we need to order it by the wowTreeIndex (the order left to right then down that actual talents appear on the UI).
	--The wowTreeIndex is not the same as how blizzard has the index ordered in GetTalentInfo(tab, index).
	--Number 1 in the Blizzard index could be number 15 in the order they're displayed etc.
	--We want our table ordered in the order they're displayed for eaze of use (and how Nova Raid Companion requires it).
	--Bit messy, but works..
	local rows = {};
	local audit2 = 0;
	for tab, tabData in ipairs(data) do
		--Create tables with row/column for each talent in order.
		if (not rows[tab]) then
			rows[tab] = {};
		end
		for k, talent in ipairs(tabData.talents) do
			if (not rows[tab][talent.info.row]) then
				rows[tab][talent.info.row] = {};
			end
			rows[tab][talent.info.row][talent.info.column] = talent.info.name;
			audit2 = audit2 + 1;
		end
	end
	--Iterate the row/colum data in order for each tree and assign the wowTreeIndex number.
	local audit3 = 0;
	for tab, tabData in ipairs(rows) do
		local count = 0;
		for row, rowData in ipairs(tabData) do
			for column, talentName in NRC:pairsByKeys(rowData) do
				count = count + 1;
				--Find the correct talent name and insert the index, should work fine as talent names are always unique (I hope).
				for k, v in ipairs(data[tab].talents) do
					if (v.info.name == talentName) then
						v.info.wowTreeIndex = count;
						audit3 = audit3 + 1;
					end
				end
			end
		end
	end
	
	for k, v in ipairs(errors) do
		print ("(Error)", v.name .. ":", v.desc);
	end
	--Audit and make sure every entry has a wowTreeIndex.
	for tab, tabData in ipairs(data) do
		for k, v in ipairs(tabData.talents) do
			if (not v.info.wowTreeIndex) then
				print("Missing wowTreeIndex - Tab:", tab, "Row:", v.info.row, "Column:", v.info.column, "Name:", v.info.name);
			end
		end
	end
	print(class .. " Audit results (these numbers should match):", audit, audit2, audit3); --Total talents effects during each step, these should match or there's a problem.
	--Finally sort each tab by wowTreeIndex.
	for tab, tabData in ipairs(data) do
		table.sort(tabData.talents, function(a, b) return a.info.wowTreeIndex < b.info.wowTreeIndex end);
	end
	return data, audit, audit2, audit3;
end

local f = CreateFrame("Frame");
f:RegisterEvent("PLAYER_ENTERING_WORLD");
f:SetScript("OnEvent", function(self, event, ...)
	C_Timer.After(5, function()
		--To match a format for easy pasting into my db file.
		talentData.talents = {};
		local classes = {"druid", "hunter", "mage", "paladin", "priest", "rogue", "shaman", "warlock", "warrior"};
		local auditTotal, audit2Total, audit3Total = 0, 0, 0;
		for k, v in pairs(classes) do
			local data, audit, audit2, audit3 = NTE:generateTalentData(v);
			auditTotal, audit2Total, audit3Total = auditTotal + audit, audit2Total + audit2, audit3Total + audit3;
			talentData.talents[v] = data;
		end
		print("|cFFFFFF00Total Audit results|r (these numbers should match):", auditTotal, audit2Total, audit3Total);
		updateSavedVariables();
	end)
	f:UnregisterEvent("PLAYER_ENTERING_WORLD");
end)

--Old stuff, was going to insert spellIDs via tooltip ingame instead at first.

--Insert extra data from tooltip.
--[[local function insertTooltipData(...)
	local _, tab, index = ...;
	local spellName, spellID = GameTooltip:GetSpell();
	if (tab and spellID) then
		local name, icon, row, column, rank, maxRank, isExceptional, available, previewRank, previewAvailable, _,  talentID  = GetTalentInfo(tab, index);
		GetTalentTabInfo(tab)
		--talentRankSpellIds = {},
		for k, v in pairs(talentData) do
			if (k == tab) then
				if (v.talents) then
					for k, v in pairs(v.talents) do
						
					end
				end
			end
		end
		print("|cFF00FF00Inserted talent data:|r", tab, index, spellName, spellID);
	else
		print("|cFFFF0000Error inserting talent data:|r", tab, index);
	end
	updateSavedVariables();
end
hooksecurefunc(GameTooltip, "SetTalent", insertTooltipData);]]

--Working Forever func for class we're currently on, changed to allow any class above.
--[[function NTE:generateTalentData(class)
	talentData = {};
	local audit = 0;
	local errors = {};
	
	local temp = {};
	
	local configID = C_ClassTalents.GetActiveConfigID();
	local configInfo = C_Traits.GetConfigInfo(configID)
	if configInfo == nil then return end
	for _, treeID in ipairs(configInfo.treeIDs) do
	    local nodes = C_Traits.GetTreeNodes(treeID)
	    for i, nodeID in ipairs(nodes) do
	    	local nodeInfo = C_Traits.GetNodeInfo(configID, nodeID);
	    	local spellInfo;
			for _, entryID in pairs(nodeInfo.entryIDs) do
				local entryInfo = C_Traits.GetEntryInfo(configID, entryID)
			    if entryInfo and entryInfo.definitionID then
			        local definitionInfo = C_Traits.GetDefinitionInfo(entryInfo.definitionID)
			        spellInfo = C_Spell.GetSpellInfo(definitionInfo.spellID);
			    end
			end
	    	local column, row = LibTalentTree:GetNodeGridPosition(nodeID);
	    	--If column or row is mssing it's a talent outside the UI blizz hasn't removed yet.
	    	if (column and row) then
		    	local tab = column < 5 and 1 or column < 9 and 2 or 3;
		    	--Convert the overall column to per spec column.
		    	if (tab == 2) then
		    		column = column - 4;
		    	end
		    	if (tab == 3) then
		    		column = column - 8;
		    	end
				local t = {
					row = row,
					icon = spellInfo.iconID,
					ranks = nodeInfo.maxRanks,
					--wowTreeIndex = count, --This is inserted below.
					column = column,
					name = spellInfo.name,
					nodeID = nodeID,
				};
				
				local talentInfoQuery = {
					specializationIndex = 1,
				    talentIndex = 1,
				    --tier = 1,
				};
				--talentID is dead in forever.
				--local talentInfo = C_SpecializationInfo.GetTalentInfo(talentInfoQuery);
				--local talentID = talentInfo.talentID;
				--if (data[talentID]) then
				--	local r = {};
				--	for k, v in pairs(data[talentID]) do
				--		--0 means no rank exists for this rank num.
				--		if (v ~= 0) then
				--			tinsert(r, v);
				--		end
				--	end
				--	t.talentRankSpellIds = r;
				--end
				
				if (not temp[tab]) then
		    		temp[tab] = {};
		    	end
				tinsert(temp[tab], t);
				temp[tab].treeID = treeID;
			end
	    end
	end
	
	for tab, tabData in ipairs(temp) do
		talentData[tab] = {};
		talentData[tab].talents = {};
		local count = 0;
		for k, v in ipairs(tabData) do
			count = count + 1;
			talentData[tab].talents[count] = {};
			talentData[tab].talents[count].info = {
				row = v.row,
				icon = v.icon,
				ranks = v.ranks,
				--wowTreeIndex = count, --This is inserted below.
				column = v.column,
				name = v.name,
				talentRankSpellIds = v.talentRankSpellIds;
				nodeID = v.nodeID,
			};
			audit = audit + 1;
		end
		talentData[tab].numtalents = count;
		local displayInfo = C_Traits.GetGroupDisplayInfoByTreeID(tabData.treeID);
		talentData[tab].info = {
			--background = "PaladinHoly", --We don't us background in Forever, using the new atlas instead.
			name = displayInfo[tab].displayName,
			icon = displayInfo[tab].icon,
		};
	end]]
	
	--Leave commented out.
	--[[for tab = 1, GetNumTalentTabs() do
		talentData[tab] = {};
		talentData[tab].talents = {};
		local count = 0;
		for index = 1, GetNumTalents(tab) do
			local name, icon, row, column, rank, maxRank, isExceptional, available, previewRank, previewAvailable, _,  talentID  = GetTalentInfo(tab, index);
			if (name) then
				count = count + 1;
				--Had to change this from index to count so an entry is only inserted if it's name exists from GetTalentInfo().
				--GetNumTalents() seems to sometimes be larger than the actual talents that exist.
				--For example mage in cata has 21 talents in the arcane tree but GetNumTalents(1) returns 22.
				talentData[tab].talents[count] = {};
				talentData[tab].talents[count].info = {
					row = row,
					icon = icon,
					ranks = maxRank,
					--wowTreeIndex = count, --This is inserted below.
					column = column,
					name = name,
				};
				if (data[talentID]) then
					local t = {};
					for k, v in pairs(data[talentID]) do
						--0 means no rank exists for this rank num.
						if (v ~= 0) then
							tinsert(t, v);
						end
					end
					talentData[tab].talents[count].info.talentRankSpellIds = t;
				end
				audit = audit + 1;
			end
		end
		talentData[tab].numtalents = count;
		local _, name, _, icon, _, background = GetTalentTabInfo(tab);
		talentData[tab].info = {
			background = background,
			name = name,
			icon = icon,
		};
	end]]
	--Now we have the data we need to order it by the wowTreeIndex (the order left to right then down that actual talents appear on the UI).
	--The wowTreeIndex is not the same as how blizzard has the index ordered in GetTalentInfo(tab, index).
	--Number 1 in the Blizzard index could be number 15 in the order they're displayed etc.
	--We want our table ordered in the order they're displayed for eaze of use (and how Nova Raid Companion requires it).
	--Bit messy, but works..
	--[[local rows = {};
	local audit2 = 0;
	for tab, tabData in ipairs(talentData) do
		--Create tables with row/column for each talent in order.
		if (not rows[tab]) then
			rows[tab] = {};
		end
		for k, talent in ipairs(tabData.talents) do
			if (not talent.info.row or not talent.info.row) then
				local t = {
					name = k,
					desc = "Missing table/row.",
				};
				tinsert(errors, t);
			end
			if (not rows[tab][talent.info.row]) then
				rows[tab][talent.info.row] = {};
			end
			rows[tab][talent.info.row][talent.info.column] = talent.info.name;
			audit2 = audit2 + 1;
		end
	end
	--Iterate the row/colum data in order for each tree and assign the wowTreeIndex number.
	local audit3 = 0;
	for tab, tabData in ipairs(rows) do
		local count = 0;
		for row, rowData in ipairs(tabData) do
			for column, talentName in pairsByKeys(rowData) do
				count = count + 1;
				--Find the correct talent name and insert the index, should work fine as talent names are always unique (I hope).
				for k, v in ipairs(talentData[tab].talents) do
					if (v.info.name == talentName) then
						v.info.wowTreeIndex = count;
						audit3 = audit3 + 1;
					end
				end
			end
		end
	end
	for k, v in ipairs(errors) do
		print ("(Error)", v.name .. ":", v.desc);
	end
	--Audit and make sure every entry has a wowTreeIndex.
	for tab, tabData in ipairs(talentData) do
		for k, v in ipairs(tabData.talents) do
			if (not v.info.wowTreeIndex) then
				print("Missing wowTreeIndex - Tab:", tab, "Row:", v.info.row, "Column:", v.info.column, "Name:", v.info.name);
			end
		end
	end
	print("Talent Audit results (these numbers should match):", audit, audit2, audit3); --Total talents effects during each step, these should match or there's a problem.
	--Finally sort each tab by wowTreeIndex.
	for tab, tabData in ipairs(talentData) do
		table.sort(tabData.talents, function(a, b) return a.info.wowTreeIndex < b.info.wowTreeIndex end);
	end
	updateSavedVariables();
end]]